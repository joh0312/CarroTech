
package Controlador;

import Vista.JFrRegistrarAlquiler;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author John
 */
public class CtrlRegistrarAlquiler implements ActionListener{
    private JFrRegistrarAlquiler JFrRegistrarAlquiler;

    public CtrlRegistrarAlquiler(JFrRegistrarAlquiler JFrRegistrarAlquiler) {
        this.JFrRegistrarAlquiler=JFrRegistrarAlquiler;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
    }
    
}
